package com.example.login_app

enum class SortType  {
    NAME,
    PRICE,
    CATEGORY
}